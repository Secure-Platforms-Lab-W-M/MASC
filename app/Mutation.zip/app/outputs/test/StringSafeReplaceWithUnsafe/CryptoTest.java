public class CryptoTest {
  public static void main(java.lang.String[] args) throws java.lang.Exception {
    java.lang.System.out.println("Hello");
    MessageDigest.getInstance("aes".replace("aes", "des"));
  }
}
