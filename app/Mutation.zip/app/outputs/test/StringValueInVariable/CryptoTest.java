public class CryptoTest {
  public static void main(java.lang.String[] args) throws java.lang.Exception {
    java.lang.System.out.println("Hello");
    String cryptoDigest = "des";
    MessageDigest.getInstance(cryptoDigest);
  }
}
